# -*- coding: utf-8 -*-
"""
Created on Mon Feb 10 20:31:02 2020

@author:  Aditya Vashista (101703039,TIET)
"""
from outlier_AdityaVashista_101703039.outlier import outlier,IQR